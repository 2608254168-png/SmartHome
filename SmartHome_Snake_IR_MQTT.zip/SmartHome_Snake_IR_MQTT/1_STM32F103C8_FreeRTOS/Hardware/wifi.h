#ifndef _WIFI_H_
#define _WIFI_H_

#include "stm32f10x.h"
#include "usart2.h"
#include "systick.h"
#include "relay.h"
#include "dc_motor.h"
#include "led.h"
#include "step_motor.h"
#include "rgb.h"
#include "dht11.h"
#include "safety.h"

uint8_t hex_char2val(char c);
uint8_t WiFi_MQTTPublish(char *topic,char *data);
void parse_rgb_hex(char *str,uint8_t *r,uint8_t *g,uint8_t *b);
void WiFi_Init(void);
uint8_t WiFi_SendAT(char *cmd,uint32_t timeout);
uint8_t WiFi_Connect(char *ssid,char *pwd);
uint8_t WiFi_SetMQTT(char *client,char* username,char *password);
uint8_t WiFi_MQTTConnect(char *server);
uint8_t WiFi_MQTTSubscribe(char *topic);
uint8_t WiFi_MQTTWaitConnected(uint32_t timeout);  //等待MQTT真正连接成功
void WiFi_MQTTReconnect(void);                     //MQTT断线重连
uint8_t WiFi_MQTTQueryState(void);                 //查询MQTT真实连接状态(AT+MQTTCONN?)
void WiFi_ParseData(void);
void WiFi_DHT11_Upload(void);
void WiFi_DeviceStateUpload(void);
void WiFi_Safety_Upload(void);

/* SNTP */
uint8_t WiFi_SNTP_Config(void);
uint8_t WiFi_SNTP_SyncTime(void);
uint8_t WiFi_SNTP_TryResync(void);
#endif
// #ifndef _WIFI_H_
// #define _WIFI_H_

// #include "stm32f10x.h"
// #include "usart2.h"
// #include "systick.h"
// #include "relay.h"
// #include "dc_motor.h"
// #include "led.h"
// #include "step_motor.h"
// #include "rgb.h"
// #include "dht11.h"

// uint8_t hex_char2val(char c);
// uint8_t WiFi_MQTTPublish(char *topic, char *data);
// void parse_rgb_hex(char *str, uint8_t *r, uint8_t *g, uint8_t *b);
// void WiFi_Init(void);
// uint8_t WiFi_SendAT(char *cmd, uint32_t timeout);
// uint8_t WiFi_Connect(char *ssid, char *pwd);
// uint8_t WiFi_SetMQTT(char *client, char *username, char *password);
// uint8_t WiFi_MQTTConnect(char *server);
// uint8_t WiFi_MQTTSubscribe(char *topic);
// uint8_t WiFi_MQTTWaitConnected(uint32_t timeout);
// void WiFi_MQTTReconnect(void);
// uint8_t WiFi_MQTTQueryState(void);
// void WiFi_ParseData(void);
// void WiFi_DHT11_Upload(void);
// void WiFi_DeviceStateUpload(void);

// /* SNTP */
// uint8_t WiFi_SNTP_Config(void);
// uint8_t WiFi_SNTP_SyncTime(void);
// uint8_t WiFi_SNTP_TryResync(void);

// #endif