#ifndef _RGB_H_
#define _RGB_H_

#include "stm32f10x.h"
#include "stdio.h"
#include "systick.h"

void RGB_Init(void);
void RGB_Color_Control(uint8_t r, uint8_t g, uint8_t b);



#endif
