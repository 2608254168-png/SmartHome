#include "step_motor.h"

void Step_Motor_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    PA4_L;PA5_L;PA6_L;PA7_L;
}

void Step_Motor_Run(uint8_t dir, uint16_t circle)
{
    if(dir == 0)//˳ʱ��
    {
        while(circle--)
        {
            PA7_H;PA6_L;PA5_L;PA4_H;
            vTaskDelay(1);
            PA7_L;PA6_H;PA5_L;PA4_H;
            vTaskDelay(1);
            PA7_L;PA6_H;PA5_H;PA4_L;
            vTaskDelay(1);
            PA7_H;PA6_L;PA5_H;PA4_L;
            vTaskDelay(1);
        }
    }
    else if(dir == 1)
    {
        while(circle--)
        {
            PA7_H;PA6_L;PA5_H;PA4_L;
            vTaskDelay(1);
            PA7_L;PA6_H;PA5_H;PA4_L;
            vTaskDelay(1);
            PA7_L;PA6_H;PA5_L;PA4_H;
            vTaskDelay(1);
            PA7_H;PA6_L;PA5_L;PA4_H;
            vTaskDelay(1);
        }
    }
    PA7_L;PA6_L;PA5_L;PA4_L;//����״̬
}

