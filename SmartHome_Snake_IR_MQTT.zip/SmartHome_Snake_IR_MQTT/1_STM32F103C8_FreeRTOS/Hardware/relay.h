#ifndef _RELAY_H_
#define _RELAY_H_

#include "stm32f10x.h"

#define RELAY_ON      GPIO_SetBits(GPIOB, GPIO_Pin_1)
#define RELAY_OFF     GPIO_ResetBits(GPIOB, GPIO_Pin_1)

void Relay_Init(void);

#endif
