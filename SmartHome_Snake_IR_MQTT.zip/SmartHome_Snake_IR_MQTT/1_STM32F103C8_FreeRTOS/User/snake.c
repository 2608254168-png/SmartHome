/* Snake game module - contains all snake game logic */
#include "snake.h"


#define SNAKE_COLS       16
#define SNAKE_ROWS       6
#define SNAKE_MAX_LEN    64
#define SNAKE_CELL_W     8
#define SNAKE_CELL_H     8
#define SNAKE_TOP_Y      8
#define SNAKE_TICK_MS    180

typedef struct
{
    uint8_t x;
    uint8_t y;
} SnakeNode_T;

static SnakeNode_T s_snake[SNAKE_MAX_LEN];
static uint8_t s_len;
static uint8_t s_food_x;
static uint8_t s_food_y;
static uint8_t s_dir;
static uint8_t s_next_dir;
static uint16_t s_score;
static uint8_t s_running;
static uint8_t s_game_over;
static TickType_t s_last_tick;
static uint32_t s_rand_seed = 0x13572468UL;

static uint8_t Snake_IsOpposite(uint8_t a, uint8_t b)
{
    if((a == 0 && b == 1) || (a == 1 && b == 0)) return 1;
    if((a == 2 && b == 3) || (a == 3 && b == 2)) return 1;
    return 0;
}

static uint8_t Snake_HitSnake(uint8_t x, uint8_t y)
{
    uint8_t i;

    for(i = 0; i < s_len; i++)
    {
        if(s_snake[i].x == x && s_snake[i].y == y)
            return 1;
    }
    return 0;
}

static uint32_t Snake_Rand(void)
{
    s_rand_seed ^= s_rand_seed << 13;
    s_rand_seed ^= s_rand_seed >> 17;
    s_rand_seed ^= s_rand_seed << 5;
    return s_rand_seed;
}

static void Snake_NewFood(void)
{
    uint16_t i;
    uint8_t x;
    uint8_t y;

    for(i = 0; i < 100; i++)
    {
        x = (uint8_t)(Snake_Rand() % SNAKE_COLS);
        y = (uint8_t)(Snake_Rand() % SNAKE_ROWS);

        if(!Snake_HitSnake(x, y))
        {
            s_food_x = x;
            s_food_y = y;
            return;
        }
    }

    s_food_x = 15;
    s_food_y = 5;
}

void Snake_Init(void)
{
    s_len = 3;

    s_snake[0].x = 8;
    s_snake[0].y = 3;
    s_snake[1].x = 7;
    s_snake[1].y = 3;
    s_snake[2].x = 6;
    s_snake[2].y = 3;

    s_dir = 3;
    s_next_dir = 3;
    s_score = 0;
    s_running = 1;
    s_game_over = 0;
    s_last_tick = xTaskGetTickCount();

    s_rand_seed ^= (uint32_t)s_last_tick + 0x9E3779B9UL;
    Snake_NewFood();
}

uint8_t Snake_IsRunning(void)
{
    return s_running;
}

void Snake_HandleKey(uint8_t key)
{
    if(s_game_over)
    {
        if(key == 'e')
        {
            s_running = 0;
        }
        else if(key == 'u' || key == 'd' || key == 'l' || key == 'r')
        {
            Snake_Init();
        }
        return;
    }

    if(key == 'e')
    {
        s_running = 0;
        return;
    }

    if(key == 'u' && !Snake_IsOpposite(s_dir, 0))
        s_next_dir = 0;
    else if(key == 'd' && !Snake_IsOpposite(s_dir, 1))
        s_next_dir = 1;
    else if(key == 'l' && !Snake_IsOpposite(s_dir, 2))
        s_next_dir = 2;
    else if(key == 'r' && !Snake_IsOpposite(s_dir, 3))
        s_next_dir = 3;
}

void Snake_Update(void)
{
    TickType_t now;
    uint8_t nx;
    uint8_t ny;
    uint8_t i;
    uint8_t grow = 0;

    if(!s_running || s_game_over)
        return;

    now = xTaskGetTickCount();
    if((now - s_last_tick) < pdMS_TO_TICKS(SNAKE_TICK_MS))
        return;

    s_last_tick = now;
    s_dir = s_next_dir;

    nx = s_snake[0].x;
    ny = s_snake[0].y;

    if(s_dir == 0) ny--;
    else if(s_dir == 1) ny++;
    else if(s_dir == 2) nx--;
    else nx++;

    if(nx >= SNAKE_COLS || ny >= SNAKE_ROWS)
    {
        s_game_over = 1;
        return;
    }

    if(nx == s_food_x && ny == s_food_y)
        grow = 1;

    if(!grow && s_len > 0)
    {
        /* 移动时允许头部进入原尾巴所在位置 */
        for(i = 0; i < s_len - 1; i++)
        {
            if(s_snake[i].x == nx && s_snake[i].y == ny)
            {
                s_game_over = 1;
                return;
            }
        }
    }
    else
    {
        if(Snake_HitSnake(nx, ny))
        {
            s_game_over = 1;
            return;
        }
    }

    if(grow)
    {
        if(s_len < SNAKE_MAX_LEN)
            s_len++;
        else
            s_game_over = 1;

        s_score++;
    }

    for(i = s_len - 1; i > 0; i--)
        s_snake[i] = s_snake[i - 1];

    s_snake[0].x = nx;
    s_snake[0].y = ny;

    if(grow)
        Snake_NewFood();
}

static void Snake_Draw(void)
{
    uint8_t i;
    uint8_t x;
    uint8_t y;

    OLED_Printf(0, 0, OLED_6X8, "SNAKE  SCORE:%03d", s_score);

    for(i = 0; i < s_len; i++)
    {
        x = s_snake[i].x * SNAKE_CELL_W;
        y = SNAKE_TOP_Y + s_snake[i].y * SNAKE_CELL_H;

        if(i == 0)
            OLED_DrawRectangle(x + 1, y + 1, 6, 6, OLED_FILLED);
        else
            OLED_DrawRectangle(x + 2, y + 2, 4, 4, OLED_FILLED);
    }

    x = s_food_x * SNAKE_CELL_W;
    y = SNAKE_TOP_Y + s_food_y * SNAKE_CELL_H;
    OLED_DrawRectangle(x + 2, y + 2, 4, 4, OLED_FILLED);

    OLED_DrawLine(0, 56, 127, 56);

    if(s_game_over)
        OLED_Printf(20, 58, OLED_6X8, "GAME OVER  E:EXIT");
    else
        OLED_Printf(4, 58, OLED_6X8, "U/D/L/R MOVE  E EXIT");
}

void Snake_Show(void)
{
    Snake_Draw();
}
