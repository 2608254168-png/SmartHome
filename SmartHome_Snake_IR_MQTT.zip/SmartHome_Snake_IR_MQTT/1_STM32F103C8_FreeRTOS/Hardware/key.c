#include "key.h"

uint8_t Key_Num;

//KEY1---PA0  KEY2---PA8  KEY3---PB10
void Key_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure = {0};
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB,ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_8;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(GPIOA,&GPIO_InitStructure);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_Init(GPIOB,&GPIO_InitStructure);
}

uint8_t Key_Scan(void)//����ɨ��
{
    uint8_t temp = 0;
    if(Key_Num != 0)
    {
        temp = Key_Num;
        Key_Num = 0;
    }
    return temp;
}

uint8_t Key_GetNum(void)//������ȡ
{
    if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0) == 1)
    {
        return 1;
    }
    else if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_8) == 0)
    {
        return 2;
    }
    else if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_10) == 0)
    {
        return 3;
    }
    return 0;
}

void Key_Tick(void)//�������
{
	static uint8_t current_state;
	static uint8_t Previous_state;

    Previous_state = current_state;//ǰһ��״̬
    current_state = Key_GetNum();//��ǰ״̬
    if(current_state == 0 && Previous_state != 0)//�������ֵ���һ��
    {
        Key_Num = Previous_state;
    }
}

