#ifndef _SNAKE_H_
#define _SNAKE_H_

#include "stm32f10x.h"
#include "oled.h"
#include "FreeRTOS.h"
#include "task.h"

void Snake_Init(void);
void Snake_Update(void);
void Snake_Show(void);
void Snake_HandleKey(uint8_t key);
uint8_t Snake_IsRunning(void);

#endif
