#ifndef _APP_H_
#define _APP_H_

#include "stm32f10x.h"                  // Device header
#include "led.h"
#include "FreeRTOS.h"
#include "task.h"
#include "tim1.h"
#include "key.h"
#include "timers.h"
#include "usart1.h"
#include "relay.h"
#include "dc_motor.h"
#include "step_motor.h"
#include "rgb.h"
#include "systick.h"
#include "dht11.h"
#include "infrared.h"
#include "oled.h"
#include "rtc.h"
#include "usart2.h"
#include "wifi.h"
#include "menu.h"
#include "safety.h"


void App_Init(void);
void Task_Start(void *pvParameters);
void Task_Safety(void *pvParameters);
#endif

