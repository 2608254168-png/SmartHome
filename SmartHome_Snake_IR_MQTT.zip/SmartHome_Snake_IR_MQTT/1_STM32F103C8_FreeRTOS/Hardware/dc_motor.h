#ifndef _DC_MOTOR_H_
#define _DC_MOTOR_H_

#include "stm32f10x.h"

void DC_Motor_Init(void);
void DC_Motor_SetSpeed(int8_t speed);

#endif
