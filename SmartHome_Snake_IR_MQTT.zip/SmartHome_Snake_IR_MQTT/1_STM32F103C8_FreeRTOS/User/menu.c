#include "menu.h"

/* ===== 设备状态 ===== */
DevState_T g_dev;

/* ===== 菜单状态 ===== */
MenuState_E g_menu = MENU_IDLE;
uint8_t g_menu_idx = 0;
uint8_t g_main_top = 0;
uint8_t g_light_idx = 0;
volatile uint8_t g_dev_report_pending = 0;

/* RGB 调节用的 HSV 状态（左右键调色相，上下键调亮度） */
static uint16_t s_hue = 0;    /* 0~359 */
static uint8_t  s_sat = 255;  /* 0~255 */
static uint8_t  s_val = 128;  /* 0~255 */
/* RGB 通道选择：0=R  1=G  2=B */
static uint8_t s_rgb_sel = 0;
/* HSV -> RGB */
static void HsvToRgb(uint16_t h, uint8_t s, uint8_t v,
                     uint8_t *r, uint8_t *g, uint8_t *b)
{
    uint16_t region, remainder, p, q, t;

    if(s == 0) { *r = v; *g = v; *b = v; return; }
    if(h >= 360) h = 359;

    region = h / 60;
    remainder = (h % 60) * 255 / 60;

    p = (v * (255 - s)) / 255;
    q = (v * (255 - (s * remainder) / 255)) / 255;
    t = (v * (255 - (s * (255 - remainder)) / 255)) / 255;

    switch(region)
    {
    case 0: *r = v; *g = t; *b = p; break;
    case 1: *r = q; *g = v; *b = p; break;
    case 2: *r = p; *g = v; *b = t; break;
    case 3: *r = p; *g = q; *b = v; break;
    case 4: *r = t; *g = p; *b = v; break;
    default: *r = v; *g = p; *b = q; break;
    }
}

/* RGB -> HSV */
static void RgbToHsv(uint8_t r, uint8_t g, uint8_t b,
                     uint16_t *h, uint8_t *s, uint8_t *v)
{
    uint8_t max, min;
    uint16_t delta;

    max = r; if(g > max) max = g; if(b > max) max = b;
    min = r; if(g < min) min = g; if(b < min) min = b;
    *v = max;
    delta = max - min;

    if(delta == 0) { *h = 0; *s = 0; return; }
    *s = delta * 255 / max;

    if(max == r)      *h = (uint16_t)((((int)g - b) * 60 / delta) + 360) % 360;
    else if(max == g) *h = (uint16_t)((((int)b - r) * 60 / delta) + 120) % 360;
    else              *h = (uint16_t)((((int)r - g) * 60 / delta) + 240) % 360;
}

/**
 * @brief 初始化菜单和设备状态
 * @details 将所有设备控制变量重置为默认状态，并将菜单系统重置为空闲状态
 */
void Menu_Init(void)
{
    // 初始化所有LED灯为关闭状态
    g_dev.led1 = 0;
    g_dev.led2 = 0;
    g_dev.led3 = 0;
    // 初始化继电器为关闭状态
    g_dev.relay = 0;
    // 初始化窗帘为关闭状态
    g_dev.curtain = 0;
    // 初始化风扇为关闭状态
    g_dev.fan = 0;
    // 初始化RGB灯所有颜色通道为关闭状态
    g_dev.rgb_r = 0;
    g_dev.rgb_g = 0;
    g_dev.rgb_b = 0;

    // 重置菜单状态为空闲状态
    g_menu = MENU_IDLE;
    // 重置菜单索引为0
    g_menu_idx = 0;
    // 重置主菜单顶部索引为0
    g_main_top = 0;
    // 重置灯光索引为0
    g_light_idx = 0;
    // 重置设备报告待处理标志为0
    g_dev_report_pending = 0;
}

/* 把 g_dev 统一应用到硬件 */
void Dev_Apply(void)
{
    /* 灯 */
    if(g_dev.led1) LED1_ON; else LED1_OFF;
    if(g_dev.led2) LED2_ON; else LED2_OFF;
    if(g_dev.led3) LED3_ON; else LED3_OFF;

    /* 插座(继电器) */
    if(g_dev.relay) RELAY_ON; else RELAY_OFF;

    /* 窗帘(直流电机) */
    if(g_dev.curtain) DC_Motor_SetSpeed(50); else DC_Motor_SetSpeed(0);

    /* 风扇(步进电机) */
    if(g_dev.fan > 0)        Step_Motor_Run(0, g_dev.fan * 10);   /* 正转 */
    else if(g_dev.fan < 0)   Step_Motor_Run(1, -g_dev.fan * 10);  /* 反转 */
    else                     { PA4_L; PA5_L; PA6_L; PA7_L; }      /* 停止 */

    /* 彩灯 */
    RGB_Color_Control(g_dev.rgb_r, g_dev.rgb_g, g_dev.rgb_b);
}

void Dev_MarkLocalChange(void)
{
    g_dev_report_pending = 1;
}

/* ================== 各界面绘制 ================== */

/* 画顶部标题栏 + 底部分隔线 */
static void Menu_DrawTitleBar(const char *title)
{
    OLED_DrawRectangle(0, 0, 128, 14, OLED_FILLED);   /* 实心标题条 */
    OLED_ReverseArea(0, 0, 128, 14);                   /* 反色：白底黑字效果 */
    OLED_Printf(4, 3, OLED_6X8, "%s", title);
    OLED_DrawLine(0, 15, 127, 15);                     /* 标题下划线 */
}

/* 底部提示栏 */
static void Menu_DrawHint(const char *hint)
{
    OLED_DrawLine(0, 54, 127, 54);
    OLED_Printf(2, 56, OLED_6X8, "%s", hint);
}

static void Menu_ShowIdle(void)
{
    float temp;
    uint8_t humi;
    static uint8_t th_cnt = 0;
    static float s_temp = 0;
    static uint8_t s_humi = 0;

    My_RTG_GetTime();

    /* 时间大字 */
    OLED_Printf(8, 2, OLED_8X16, "%02d:%02d:%02d",
                My_Time[3], My_Time[4], My_Time[5]);
    OLED_Printf(16, 20, OLED_6X8, "%04d-%02d-%02d",
                My_Time[0], My_Time[1], My_Time[2]);

    /* 温湿度 */
    if (++th_cnt >= 20)
    {
        th_cnt = 0;
        if (DHT11_GetData(&temp, &humi) == 0)
        {
            s_temp = temp;
            s_humi = humi;
        }
    }
    OLED_DrawLine(0, 32, 127, 32);
    OLED_Printf(4, 36, OLED_6X8, "TEMP  %5.1f C", s_temp);
    OLED_Printf(4, 46, OLED_6X8, "HUMI  %3d %%", s_humi);

    /* 底部联网状态 */
    OLED_DrawLine(0, 54, 127, 54);
    if (mqtt_connected)
        OLED_Printf(4, 56, OLED_6X8, "[NET ON]  press any");
    else
        OLED_Printf(4, 56, OLED_6X8, "[NET OFF] press any");
}

/**
 * @brief 显示主菜单界面
 * @note 该函数用于在OLED屏幕上显示智能家居的主菜单选项
 */
static void Menu_ShowMain(void)
{
    // 定义菜单选项数组，包含7个智能家居设备选项
    static const char *items[7] = {
        "Light", "Socket", "Fan", "Curtain", "RGB", "Network", "Snake"
    };
    uint8_t i;           // 循环计数器
    uint8_t y;           // OLED屏幕Y坐标
    uint8_t item;        // 当前菜单项索引

    // 绘制标题栏，显示"== SMART HOME =="
    Menu_DrawTitleBar("== SMART HOME ==");

    // 循环显示前5个菜单项
    for(i = 0; i < 5; i++)
    {
        item = g_main_top + i;  // 计算当前菜单项索引
        if(item >= 7)           // 检查是否超出菜单项范围
            break;              // 超出范围则退出循环

        y = 18 + i * 8;        // 计算当前菜单项的Y坐标

        // 如果当前菜单项是被选中的项
        if(item == g_menu_idx)
        {
            // 绘制选中项的背景（填充矩形）
            OLED_DrawRectangle(2, y - 1, 124, 8, OLED_FILLED);
            // 反转选中项区域的颜色
            OLED_ReverseArea(2, y - 1, 124, 8);
            // 显示选中项，前面添加">"符号
            OLED_Printf(8, y, OLED_6X8, "> %s", items[item]);
        }
        else
        {
            // 显示未选中项，前面添加两个空格
            OLED_Printf(8, y, OLED_6X8, "  %s", items[item]);
        }
    }

}

/**
 * @brief 显示LED菜单界面
 * @note 此函数用于在OLED屏幕上显示LED控制菜单，包括LED1、LED2、LED3的状态和当前选中项
 */
static void Menu_ShowLight(void)
{
    // 定义LED名称数组，使用static const确保数据存储在只读区域
    static const char *name[3] = {"LED1", "LED2", "LED3"};
    // 获取三个LED的状态，存储在数组中
    uint8_t st[3] = {g_dev.led1, g_dev.led2, g_dev.led3};
    // 定义循环计数器
    uint8_t i;

    // 绘制菜单标题栏
    Menu_DrawTitleBar("-- LIGHT --");

    // 遍历所有LED选项
    for (i = 0; i < 3; i++)
    {
        // 计算当前选项的Y坐标位置
        uint8_t y = 20 + i * 12;
        // 如果当前选项是选中项，则高亮显示
        if (i == g_light_idx)
        {
            // 绘制填充矩形作为背景
            OLED_DrawRectangle(4, y - 1, 120, 11, OLED_FILLED);
            // 反转指定区域颜色以突出显示
            OLED_ReverseArea(4, y - 1, 120, 11);
        }
        // 打印LED名称和状态
        OLED_Printf(12, y, OLED_6X8, "%s   [%s]",
                    name[i], st[i] ? " ON " : "OFF ");
    }
    // 绘制操作提示
    Menu_DrawHint("< back   E switch");
}

/**
 * @brief 显示SOCKET菜单界面
 * 该函数用于在OLED屏幕上绘制SOCKET控制菜单，包括标题栏、SOCKET状态显示和操作提示
 */
static void Menu_ShowSocket(void)
{
    // 绘制标题栏，显示"-- SOCKET --"
    Menu_DrawTitleBar("-- SOCKET --");

    // 在指定位置显示"SOCKET"文本
    OLED_Printf(16, 24, OLED_8X16, "SOCKET");
    // 检查继电器(relay)状态
    if (g_dev.relay)
    {
        // 如果继电器开启状态：
        // 绘制填充矩形框
        OLED_DrawRectangle(80, 22, 36, 18, OLED_FILLED);
        // 反转指定区域显示
        OLED_ReverseArea(80, 22, 36, 18);
        // 显示" ON "文本
        OLED_Printf(86, 26, OLED_6X8, " ON ");
    }
    else
    {
        // 如果继电器关闭状态：
        // 绘制未填充矩形框
        OLED_DrawRectangle(80, 22, 36, 18, OLED_UNFILLED);
        // 显示"OFF "文本
        OLED_Printf(86, 26, OLED_6X8, "OFF ");
    }

    // 绘制操作提示，显示返回和切换按钮的说明
    Menu_DrawHint("< back   E toggle");
}

/**
 * @brief 显示风扇控制菜单
 * @note 该函数在OLED屏幕上显示风扇的当前状态和控制提示
 */
static void Menu_ShowFan(void)
{
    int16_t abs_fan = g_dev.fan >= 0 ? g_dev.fan : -g_dev.fan;  // 计算风扇速度的绝对值
    uint8_t bar_w;  // 进度条宽度变量

    // 绘制标题栏
    Menu_DrawTitleBar("-- FAN --");

    // 显示风扇速度值
    OLED_Printf(8, 20, OLED_6X8, "Speed: %4d", g_dev.fan);

    /* 简易进度条 0~100 */
    OLED_DrawRectangle(8, 34, 112, 10, OLED_UNFILLED);
    bar_w = (uint8_t)(abs_fan * 110 / 100);
    if (bar_w > 0)
        OLED_DrawRectangle(9, 35, bar_w, 8, OLED_FILLED);

    if (g_dev.fan > 0)
        OLED_Printf(8, 46, OLED_6X8, ">> FWD");
    else if (g_dev.fan < 0)
        OLED_Printf(8, 46, OLED_6X8, "<< REV");
    else
        OLED_Printf(8, 46, OLED_6X8, "-- STOP");

    Menu_DrawHint("U/D dir  R+10  E stop");
}

static void Menu_ShowCurtain(void)
{
    Menu_DrawTitleBar("-- CURTAIN --");

    OLED_Printf(20, 24, OLED_8X16, "CURTAIN");
    if (g_dev.curtain)
    {
        OLED_DrawRectangle(20, 42, 88, 10, OLED_FILLED);  /* 打开状态 */
        OLED_ReverseArea(20, 42, 88, 10);
        OLED_Printf(40, 44, OLED_6X8, "  OPEN  ");
    }
    else
    {
        OLED_DrawRectangle(20, 42, 88, 10, OLED_UNFILLED);
        OLED_Printf(40, 44, OLED_6X8, " CLOSED ");
    }

    Menu_DrawHint("< back   E toggle");
}

static void Menu_ShowNet(void)
{
    Menu_DrawTitleBar("-- NETWORK --");

    if (mqtt_connected)
    {
        OLED_DrawRectangle(20, 22, 88, 16, OLED_FILLED);
        OLED_ReverseArea(20, 22, 88, 16);
        OLED_Printf(36, 26, OLED_6X8, " ONLINE ");
    }
    else
    {
        OLED_DrawRectangle(20, 22, 88, 16, OLED_UNFILLED);
        OLED_Printf(32, 26, OLED_6X8, " OFFLINE ");
    }

    OLED_Printf(8, 44, OLED_6X8, "U: re-WiFi");
    OLED_Printf(8, 52, OLED_6X8, "D: re-MQTT   < back");
}

/**
 * @brief 显示RGB设置菜单界面
 * 该函数用于在OLED屏幕上显示RGB颜色设置界面，包括三个颜色通道的柱状图和数值
 */
static void Menu_ShowRgb(void)
{
    // 定义RGB三色的高度值数组，存储当前RGB各通道的值
    uint8_t heights[3] = {g_dev.rgb_r, g_dev.rgb_g, g_dev.rgb_b};
    // 定义RGB三色在屏幕上的X坐标位置
    uint8_t pos_x[3]   = {24, 64, 104};
    // 定义RGB三色的标签字符
    char    labels[3]  = {'R', 'G', 'B'};
    uint8_t i, h;  // 循环变量和高度变量

    /* 标题 */
    OLED_Printf(0, 0, OLED_8X16, "=== RGB设置 ===");

    for(i = 0; i < 3; i++)
    {
        /* 选中通道画外框 */
        if(s_rgb_sel == i)
            OLED_DrawRectangle(pos_x[i] - 10, 16, 20, 38, OLED_UNFILLED);

        /* 柱状高度（0~255 映射到 0~30 像素） */
        h = (uint16_t)heights[i] * 30 / 255;
        if(h > 0)
            OLED_DrawRectangle(pos_x[i] - 5, 50 - h, 10, h, OLED_FILLED);

        /* 底部基线 + 字母 + 数值 */
        OLED_DrawLine(pos_x[i] - 8, 50, pos_x[i] + 8, 50);
        OLED_ShowChar(pos_x[i] - 2, 52, labels[i], OLED_6X8);
        OLED_ShowNum(pos_x[i] - 6, 18, heights[i], 3, OLED_6X8);
    }
}

static void Menu_ShowSnake(void)
{
    Snake_Show();
}

/* ================== 界面刷新（高优先级任务调用） ================== */

/**
 * @brief 更新菜单显示的函数
 * @note 该函数负责根据当前菜单状态更新OLED显示内容
 *       如果系统处于告警状态，则显示告警信息并返回
 */
void Menu_Update(void)
{
    // 检查系统是否处于告警状态
    if (Safety_IsAlerting())
    {
        // 清空OLED显示
    OLED_Clear();
        // 在OLED上显示告警文本
    OLED_Printf(0, 16, OLED_8X16, "%s", Safety_GetAlertText());
        // 显示提示信息，按KEY1键清除告警
    OLED_Printf(0, 40, OLED_6X8, "KEY1 to Clear");
        // 更新OLED显示
    OLED_Update();
    return;   // 告警期间不跑普通菜单
    }
    // 如果没有告警，清空OLED显示
    OLED_Clear();

    // 根据当前菜单状态(g_menu)的值，显示对应的菜单界面
    switch (g_menu)
    {
    case MENU_IDLE:    Menu_ShowIdle();    break;    // 显示空闲菜单
    case MENU_MAIN:    Menu_ShowMain();    break;    // 显示主菜单
    case MENU_LIGHT:   Menu_ShowLight();   break;    // 显示灯光控制菜单
    case MENU_SOCKET:  Menu_ShowSocket();  break;    // 显示插座控制菜单
    case MENU_FAN:     Menu_ShowFan();     break;    // 显示风扇控制菜单
    case MENU_CURTAIN: Menu_ShowCurtain(); break;    // 显示窗帘控制菜单
    case MENU_RGB:     Menu_ShowRgb();     break;    // 显示RGB灯控制菜单
    case MENU_NET:     Menu_ShowNet();     break;    // 显示网络设置菜单
    case MENU_SNAKE:   Snake_Update(); Menu_ShowSnake(); break;  // 更新并显示贪吃蛇游戏界面
    }
    // 更新OLED显示
    OLED_Update();
}
/* ================== 红外按键处理 ================== */
/* 键值: 'u'上 'd'下 'l'左(返回) 'r'右 'e'确认 */
void Menu_HandleKey(uint8_t key)
{
    switch(g_menu)
    {
    case MENU_IDLE:
        g_menu = MENU_MAIN;
        g_menu_idx = 0;
        g_main_top = 0;
        break;

    case MENU_MAIN:
        if(key == 'u')
        {
            if(g_menu_idx > 0)
                g_menu_idx--;
            else
                g_menu_idx = 6;

            if(g_menu_idx < g_main_top)
                g_main_top = g_menu_idx;
        }
        else if(key == 'd')
        {
            if(g_menu_idx < 6)
                g_menu_idx++;
            else
                g_menu_idx = 0;

            if(g_menu_idx >= g_main_top + 5)
                g_main_top = g_menu_idx - 4;
        }
        else if(key == 'e' || key == 'r')
        {
            switch(g_menu_idx)
            {
            case 0:
                g_menu = MENU_LIGHT;
                g_light_idx = 0;
                break;
            case 1:
                g_menu = MENU_SOCKET;
                break;
            case 2:
                g_menu = MENU_FAN;
                break;
            case 3:
                g_menu = MENU_CURTAIN;
                break;
            case 4:
                g_menu = MENU_RGB;
                RgbToHsv(g_dev.rgb_r, g_dev.rgb_g, g_dev.rgb_b,
                         &s_hue, &s_sat, &s_val);
                break;
            case 5:
                g_menu = MENU_NET;
                break;
            case 6:
                g_menu = MENU_SNAKE;
                Snake_Init();
                break;
            }
        }
        else if(key == 'l')
        {
            g_menu = MENU_IDLE;
        }
        break;

    case MENU_LIGHT:
        if(key == 'u')
            g_light_idx = (g_light_idx + 2) % 3;
        else if(key == 'd')
            g_light_idx = (g_light_idx + 1) % 3;
        else if(key == 'e')
        {
            if(g_light_idx == 0) g_dev.led1 ^= 1;
            else if(g_light_idx == 1) g_dev.led2 ^= 1;
            else g_dev.led3 ^= 1;

            Dev_Apply();
            Dev_MarkLocalChange();
        }
        else if(key == 'l')
        {
            g_menu = MENU_MAIN;
        }
        break;

    case MENU_SOCKET:
        if(key == 'e' || key == 'r')
        {
            g_dev.relay ^= 1;
            Dev_Apply();
            Dev_MarkLocalChange();
        }
        else if(key == 'l')
        {
            g_menu = MENU_MAIN;
        }
        break;

    case MENU_FAN:
        if(key == 'u')
        {
            g_dev.fan = 50;
            Dev_Apply();
            Dev_MarkLocalChange();
        }
        else if(key == 'd')
        {
            g_dev.fan = -50;
            Dev_Apply();
            Dev_MarkLocalChange();
        }
        else if(key == 'e')
        {
            g_dev.fan = 0;
            Dev_Apply();
            Dev_MarkLocalChange();
        }
        else if(key == 'r')
        {
            if(g_dev.fan <= 90)
                g_dev.fan += 10;
            Dev_Apply();
            Dev_MarkLocalChange();
        }
        else if(key == 'l')
        {
            g_menu = MENU_MAIN;
        }
        break;

    case MENU_CURTAIN:
        if(key == 'e' || key == 'r')
        {
            g_dev.curtain ^= 1;
            Dev_Apply();
            Dev_MarkLocalChange();
        }
        else if(key == 'l')
        {
            g_menu = MENU_MAIN;
        }
        break;

    case MENU_RGB:
        if(key == 'l')
        {
            if(s_rgb_sel > 0)
                s_rgb_sel--;
            else
                g_menu = MENU_MAIN;
        }
        else if(key == 'r')
        {
            if(s_rgb_sel < 2)
                s_rgb_sel++;
        }
        else if(key == 'u')
        {
            if(s_rgb_sel == 0)
            {
                if(g_dev.rgb_r < 246) g_dev.rgb_r += 10;
                else g_dev.rgb_r = 255;
            }
            else if(s_rgb_sel == 1)
            {
                if(g_dev.rgb_g < 246) g_dev.rgb_g += 10;
                else g_dev.rgb_g = 255;
            }
            else
            {
                if(g_dev.rgb_b < 246) g_dev.rgb_b += 10;
                else g_dev.rgb_b = 255;
            }

            Dev_Apply();
            Dev_MarkLocalChange();
        }
        else if(key == 'd')
        {
            if(s_rgb_sel == 0)
            {
                if(g_dev.rgb_r > 9) g_dev.rgb_r -= 10;
                else g_dev.rgb_r = 0;
            }
            else if(s_rgb_sel == 1)
            {
                if(g_dev.rgb_g > 9) g_dev.rgb_g -= 10;
                else g_dev.rgb_g = 0;
            }
            else
            {
                if(g_dev.rgb_b > 9) g_dev.rgb_b -= 10;
                else g_dev.rgb_b = 0;
            }

            Dev_Apply();
            Dev_MarkLocalChange();
        }
        else if(key == 'e')
        {
            g_menu = MENU_MAIN;
        }
        break;

    case MENU_NET:
        if(key == 'u')
            WiFi_Init();
        else if(key == 'd')
            WiFi_MQTTReconnect();
        else if(key == 'l')
            g_menu = MENU_MAIN;
        break;

    case MENU_SNAKE:
        Snake_HandleKey(key);
        if(!Snake_IsRunning())
        {
            g_menu = MENU_MAIN;
            g_main_top = 2;
            g_menu_idx = 6;
        }
        break;
    }
}

