#ifndef _MENU_H_
#define _MENU_H_

#include "stm32f10x.h"
#include "led.h"
#include "relay.h"
#include "dc_motor.h"
#include "step_motor.h"
#include "rgb.h"
#include "oled.h"
#include "rtc.h"
#include "dht11.h"
#include "usart2.h"   /* mqtt_connected */
#include "wifi.h"
#include "snake.h"     /* WiFi_Init / WiFi_MQTTReconnect */

/* ===== 设备状态（三个任务共享，以 g_dev 为准） ===== */
typedef struct
{
    uint8_t led1;
    uint8_t led2;
    uint8_t led3;
    uint8_t relay;    /* 插座 0关 1开 */
    uint8_t curtain;  /* 窗帘 0关 1开 */
    int16_t fan;      /* 风扇 -100~100 */
    uint8_t rgb_r;
    uint8_t rgb_g;
    uint8_t rgb_b;
}DevState_T;

extern DevState_T g_dev;//// 三个任务共享

/* ===== 菜单状态机 ===== */
typedef enum
{
    MENU_IDLE = 0,  /* 主界面 */
    MENU_MAIN,      /* 主菜单 */
    MENU_LIGHT,     /* 灯光 */
    MENU_SOCKET,    /* 插座 */
    MENU_FAN,       /* 风扇 */
    MENU_CURTAIN,   /* 窗帘 */
    MENU_RGB,       /* 彩灯RGB(左右键调色相) */
    MENU_NET,       /* 联网 */
    MENU_SNAKE,     /* 贪吃蛇 */
}MenuState_E;

extern MenuState_E g_menu;
extern uint8_t g_menu_idx;   /* 主菜单高亮项 0~6 */
extern uint8_t g_main_top;   /* 主菜单显示窗口 */
extern volatile uint8_t g_dev_report_pending;
extern uint8_t g_light_idx;  /* 灯光子界面高亮项 0~2 */

void Menu_Init(void);
void Menu_HandleKey(uint8_t key); /* 红外任务调用：按键->界面切换/控制器件 */
void Menu_Update(void);           /* 界面任务调用(高优先级) */
void Dev_Apply(void);
void Dev_MarkLocalChange(void);             /* 把 g_dev 统一应用到硬件 */

#endif
