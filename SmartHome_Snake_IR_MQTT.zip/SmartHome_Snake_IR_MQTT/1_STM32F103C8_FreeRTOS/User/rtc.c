#include "rtc.h"

/* ============================================================
 * 时间方案说明：
 * STM32F103 无外部32.768kHz晶振时，使用LSI做RTC会严重漂移，
 * 且mktime/localtime在部分newlib上不稳定，表现为"跑几秒就停/跳变"。
 *
 * 本文件采用：
 *   1) SNTP对时后记录基准Unix时间戳
 *   2) 使用FreeRTOS系统节拍累加秒数(系统在跑，时间就一直在走)
 *   3) 仍可可选写入硬件RTC(备用)，但不依赖它来显示
 * 这样时间可持续走秒，与云平台MQTT / 红外交互不抢占。
 * ============================================================ */
#define USE_LSE 0
uint16_t My_Time[6] = {2026, 9, 2, 12, 0, 0}; /* 年月日时分秒 */
/* 软时钟基准 */
static uint32_t s_base_unix = 0;       /* 上次对时的Unix秒 */
static TickType_t s_base_tick = 0;     /* 对时时刻的FreeRTOS tick */
static uint8_t s_need_latch = 1;       /* 调度器启动后需要锁存一次tick */
static uint8_t s_time_inited = 0;
static const uint8_t s_dim[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

static int is_leap(int y)
{
    return ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0));
}

/* 本地时间(已是东八区墙钟时间) -> Unix秒(按UTC数值编码，不做时区转换) */
static uint32_t wall_to_unix(int y, int mo, int d, int h, int mi, int s)
{
    uint32_t days = 0;
    int year, m;
    if (y < 1970) y = 1970;
    if (mo < 1) mo = 1;
    if (mo > 12) mo = 12;
    if (d < 1) d = 1;
    for (year = 1970; year < y; year++)
        days += is_leap(year) ? 366U : 365U;
    for (m = 1; m < mo; m++)
    {
        days += s_dim[m - 1];
        if (m == 2 && is_leap(y))
            days++;
    }
    days += (uint32_t)(d - 1);
    return days * 86400UL + (uint32_t)h * 3600UL + (uint32_t)mi * 60UL + (uint32_t)s;
}

/* Unix 秒 -> 墙钟数组 */
static void unix_to_wall(uint32_t t, uint16_t out[6])
{
    uint32_t days = t / 86400UL;
    uint32_t sec_of_day = t % 86400UL;
    int y = 1970;
    int mo, d, h, mi, s;
    uint32_t diy, dim;
    h = (int)(sec_of_day / 3600UL);
    mi = (int)((sec_of_day % 3600UL) / 60UL);
    s = (int)(sec_of_day % 60UL);
    while (1)
    {
        diy = is_leap(y) ? 366U : 365U;
        if (days < diy)
            break;
        days -= diy;
        y++;
    }
    for (mo = 1; mo <= 12; mo++)
    {
        dim = s_dim[mo - 1];
        if (mo == 2 && is_leap(y))
            dim++;
        if (days < dim)
            break;
        days -= dim;
    }
    d = (int)days + 1;
    out[0] = (uint16_t)y;
    out[1] = (uint16_t)mo;
    out[2] = (uint16_t)d;
    out[3] = (uint16_t)h;
    out[4] = (uint16_t)mi;
    out[5] = (uint16_t)s;
}

static void hw_rtc_init(void)
{
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
    PWR_BackupAccessCmd(ENABLE);
    /* 首次配置前复位备份域，避免残留配置导致RTC异常停走 */
    RCC_BackupResetCmd(ENABLE);
    RCC_BackupResetCmd(DISABLE);
#if USE_LSE
    RCC_LSEConfig(RCC_LSE_ON);
    while (RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET)
        ;
    RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
    RCC_RTCCLKCmd(ENABLE);
    RTC_WaitForSynchro();
    RTC_WaitForLastTask();
    RTC_SetPrescaler(32767);
    RTC_WaitForLastTask();
#else
    RCC_LSICmd(ENABLE);
    while (RCC_GetFlagStatus(RCC_FLAG_LSIRDY) == RESET)
        ;
    RCC_RTCCLKConfig(RCC_RTCCLKSource_LSI);
    RCC_RTCCLKCmd(ENABLE);
    RTC_WaitForSynchro();
    RTC_WaitForLastTask();
    /* LSI典型40kHz，仅作备用，显示不依赖它 */
    RTC_SetPrescaler(39999);
    RTC_WaitForLastTask();
#endif
}

void My_RTC_Init(void)
{
    hw_rtc_init();
    /* 使用默认My_Time建立软时钟基准(后续SNTP会覆盖) */
    s_base_unix = wall_to_unix(My_Time[0], My_Time[1], My_Time[2],
                               My_Time[3], My_Time[4], My_Time[5]);
    s_base_tick = 0;
    s_need_latch = 1;
    s_time_inited = 1;
    /* 同步写到硬件RTC(备用) */
    RTC_WaitForLastTask();
    RTC_SetCounter(s_base_unix);
    RTC_WaitForLastTask();
}

/* 把当前My_Time[]设为基准(SNTP解析后调用) */
void My_RTC_SetTime(void)
{
    s_base_unix = wall_to_unix(My_Time[0], My_Time[1], My_Time[2],
                               My_Time[3], My_Time[4], My_Time[5]);
    if (xTaskGetSchedulerState() == taskSCHEDULER_RUNNING)
    {
        s_base_tick = xTaskGetTickCount();
        s_need_latch = 0;
    }
    else
    {
        /* 调度器尚未启动：等待第一次GetTime时再锁存tick */
        s_base_tick = 0;
        s_need_latch = 1;
    }
    s_time_inited = 1;
    /* 同步硬件RTC(可选) */
    RTC_WaitForLastTask();
    RTC_SetCounter(s_base_unix);
    RTC_WaitForLastTask();
}

/* 读取时间：软时钟累加，保证持续走秒 */
void My_RTG_GetTime(void)
{
    TickType_t now;
    uint32_t elapsed_sec;
    uint32_t unix_now;
    if (!s_time_inited)
    {
        My_RTC_Init();
    }
    if (xTaskGetSchedulerState() == taskSCHEDULER_RUNNING)
    {
        if (s_need_latch)
        {
            /* 调度器刚启动，锁存当前tick作为起点，避免把启动前的窗口算进去 */
            s_base_tick = xTaskGetTickCount();
            s_need_latch = 0;
        }
        now = xTaskGetTickCount();
        elapsed_sec = (uint32_t)((now - s_base_tick) / configTICK_RATE_HZ);
    }
    else
    {
        elapsed_sec = 0;
    }
    unix_now = s_base_unix + elapsed_sec;
    unix_to_wall(unix_now, My_Time);
}