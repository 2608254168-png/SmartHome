#ifndef _KEY_H_
#define _KEY_H_

#include "stm32f10x.h"

void Key_Init(void);
uint8_t Key_GetNum(void);
void Key_Tick(void);
uint8_t Key_Scan(void);

#endif
