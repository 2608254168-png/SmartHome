#ifndef _DHT11_H_
#define _DHT11_H_

#include "stm32f10x.h"
#include "systick.h"

void DHT11_Init(void);
uint8_t DHT11_GetData(float *temperature, uint8_t *humidity);

#endif
