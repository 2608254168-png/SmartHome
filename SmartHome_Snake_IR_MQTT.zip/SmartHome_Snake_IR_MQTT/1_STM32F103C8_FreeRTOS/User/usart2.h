#ifndef _USART2_H_
#define _USART2_H_

#include "stm32f10x.h"
#include "string.h"
#include "stdio.h"
#include "led.h"
#define USART2_RX_BUF_SIZE  512

enum {
    WIFI_STATE_IDLE = 0,
    WIFI_RX_BUF_FULL,
    WIFI_AT_OK,
    WIFI_AT_ERROR,
    WIFI_MQTT_SUB,
    WIFI_MQTT_CONNECTED,     // 收到 +MQTTCONNECTED
    WIFI_MQTT_DISCONNECTED,  // 收到 +MQTTDISCONNECTED
};

typedef struct{
    uint8_t rx_buf[USART2_RX_BUF_SIZE];
    uint16_t index;
    uint8_t wifi_state;
}USART2_INFO_T;

void Usart2_Init(void);
void Usart2_SendByte(uint8_t ch);
void Usart2_SendString(uint8_t *str);
uint8_t Usart2_ReceiveByte(void);
void USART2_IRQHandler(void);
extern USART2_INFO_T usart2_info;

/* MQTT 连接状态标志：1=已连接，0=未连接/已断开（由串口2中断维护） */
extern volatile uint8_t mqtt_connected;

#endif
