#ifndef _TIM1_H_
#define _TIM1_H_

#include "stm32f10x.h"

void TIM1_Interrupt(uint16_t xms);

#endif
