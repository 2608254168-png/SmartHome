// #ifndef _RTC_H_
// #define _RTC_H_

// #include "stm32f10x.h"
// #include "led.h"
// #include "time.h"

// void My_RTC_Init(void);
// void My_RTC_SetTime(void);
// void My_RTG_GetTime(void);

// extern uint16_t My_Time[6];

// #endif
#ifndef _RTC_H_
#define _RTC_H_

#include "stm32f10x.h"
#include "FreeRTOS.h"
#include "task.h"

void My_RTC_Init(void);
void My_RTC_SetTime(void);
void My_RTG_GetTime(void);

extern uint16_t My_Time[6];

#endif