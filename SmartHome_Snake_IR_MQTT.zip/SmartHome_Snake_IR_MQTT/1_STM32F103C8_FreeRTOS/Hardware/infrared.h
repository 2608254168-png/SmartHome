#ifndef _INFRARED_H_
#define _INFRARED_H_

#include "stm32f10x.h"
#include "led.h"
#include <stdio.h>
#include <string.h>
#include "systick.h"

typedef struct
{
    uint16_t level_time[128];
    uint8_t edge_num;
    uint8_t start_flag;
    uint8_t end_flag;
    uint8_t ctrl_code;
}INFRARED_INFO_T;

void IR_Receive_Init(void);
void IR_Send_Init(void);
uint8_t IR_Receive_Encode(void);
uint8_t IR_Key_Scan(void);
void IR_Send_Code(uint8_t addr,uint8_t ctrl);

#endif
