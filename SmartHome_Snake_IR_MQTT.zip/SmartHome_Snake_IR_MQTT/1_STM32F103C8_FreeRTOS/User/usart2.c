// #include "usart2.h"

// //STM32F103C8T6配置USART2,USART2_TX->PA2,USART2_RX->PA3

// void Usart2_Init(void)
// {
//     GPIO_InitTypeDef GPIO_InitStructure={0};              //GPIO结构体
//     USART_InitTypeDef USART_InitStructure={0};            //USART结构体
//     NVIC_InitTypeDef NVIC_InitStructure={0};              //NVIC结构体

//     RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); //使能GPIOA时钟
//     RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);//使能USART2时钟

//     GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;             //PA2
//     GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;       //复用推挽输出
//     GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;     //速度50MHz
//     GPIO_Init(GPIOA, &GPIO_InitStructure);                //初始化GPIOA

//     GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;             //PA3
//     GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;         //上拉输入
//     GPIO_Init(GPIOA, &GPIO_InitStructure);                //初始化GPIOA

//     USART_InitStructure.USART_BaudRate = 115200;          //波特率
//     USART_InitStructure.USART_WordLength = USART_WordLength_8b;//数据位
//     USART_InitStructure.USART_StopBits = USART_StopBits_1;//停止位
//     USART_InitStructure.USART_Parity = USART_Parity_No;   //校验位
//     USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; //硬件流控制

//     USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx; //发送和接收
//     USART_Init(USART2, &USART_InitStructure);             //初始化USART2

//     USART_Cmd(USART2, ENABLE);                            //使能USART2

//     USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);        //开启接收中断
//     USART_ITConfig(USART2, USART_IT_IDLE, ENABLE);        

//     NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;     //USART2中断
//     NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 9;//抢占优先级
//     NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;     //子优先级
//     NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;        //使能中断
//     NVIC_Init(&NVIC_InitStructure);                        //初始化NVIC

// }

// //发送一个字节
// void Usart2_SendByte(uint8_t ch)
// {
//     USART_SendData(USART2, ch);
//     while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
// }
// //发送一个字符串
// void Usart2_SendString(uint8_t *str)
// {
//     while(*str != '\0')
//     {
//         Usart2_SendByte(*str);
//         str++;
//     }
// }

// USART2_INFO_T usart2_info;                          //USART2接收数据结构体
// volatile uint8_t mqtt_connected = 0;                //MQTT连接标志
// //接收一个字节
// uint8_t Usart2_ReceiveByte(void)
// {
//     if(USART_GetFlagStatus(USART2, USART_FLAG_RXNE) != RESET)
//     {
//         return (uint8_t)USART_ReceiveData(USART2);
//     }

//     return 0;
// }

// //中断服务函数,接收数据
// void USART2_IRQHandler(void)
// {
//     if (USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
//     {
//         USART_ClearITPendingBit(USART2, USART_IT_RXNE); //清除中断标志位
//         if(usart2_info.index < USART2_RX_BUF_SIZE-1)
//         {
//             usart2_info.rx_buf[usart2_info.index++] = USART_ReceiveData(USART2);
//               usart2_info.rx_buf[usart2_info.index] = '\0';
//         }
//         else
//         {
//             usart2_info.wifi_state = WIFI_RX_BUF_FULL;//接收缓冲区溢出
//         }
//     }
//         if (USART_GetITStatus(USART2, USART_IT_IDLE) != RESET)
//         {
//         USART2->SR;
//         USART2->DR;
//         if(strstr((char *)usart2_info.rx_buf, "+MQTTSUBRECV") != NULL)
//         {
//             usart2_info.wifi_state = WIFI_MQTT_SUB;
    
//         }
//         else if(strstr((char *)usart2_info.rx_buf, "+MQTTCONNECTED") != NULL)
//         {
//             /* MQTT 连接成功 */
//             mqtt_connected = 1;
//             usart2_info.wifi_state = WIFI_MQTT_CONNECTED;
//             printf("[MQTT] CONNECTED:%s\r\n", (char*)usart2_info.rx_buf);
//         }
//         else if(strstr((char *)usart2_info.rx_buf, "+MQTTDISCONNECTED") != NULL)
//         {
//             /* MQTT 断开连接 */
//             mqtt_connected = 0;
//             usart2_info.wifi_state = WIFI_MQTT_DISCONNECTED;
//             printf("[MQTT] DISCONNECTED:%s\r\n", (char*)usart2_info.rx_buf);
//         }
//         else if(strstr((char *)usart2_info.rx_buf, "ready") != NULL)
//         {
//             usart2_info.wifi_state = WIFI_AT_OK;
//         }
//         else if(strstr((char *)usart2_info.rx_buf, "OK") != NULL)
//         {
//             usart2_info.wifi_state = WIFI_AT_OK;
//         }
//         else if(strstr((char *)usart2_info.rx_buf, "ERROR") != NULL)
//         {
//             usart2_info.wifi_state = WIFI_AT_ERROR;
//         }
//     }
// }
#include "usart2.h"

//STM32F103C8T6閰嶇疆USART2,USART2_TX->PA2,USART2_RX->PA3

void Usart2_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure={0};              //GPIO缁撴瀯浣?
    USART_InitTypeDef USART_InitStructure={0};            //USART缁撴瀯浣?
    NVIC_InitTypeDef NVIC_InitStructure={0};              //NVIC缁撴瀯浣?

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); //浣胯兘GPIOA鏃堕挓
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);//浣胯兘USART2鏃堕挓

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;             //PA2
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;       //澶嶇敤鎺ㄦ尳杈撳嚭
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;     //閫熷害50MHz
    GPIO_Init(GPIOA, &GPIO_InitStructure);                //鍒濆鍖朑PIOA

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;             //PA3
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;         //涓婃媺杈撳叆
    GPIO_Init(GPIOA, &GPIO_InitStructure);                //鍒濆鍖朑PIOA

    USART_InitStructure.USART_BaudRate = 115200;          //娉㈢壒鐜?
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;//鏁版嵁浣?
    USART_InitStructure.USART_StopBits = USART_StopBits_1;//鍋滄浣?
    USART_InitStructure.USART_Parity = USART_Parity_No;   //鏍￠獙浣?
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None; //纭欢娴佹帶鍒?

    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx; //鍙戦€佸拰鎺ユ敹
    USART_Init(USART2, &USART_InitStructure);             //鍒濆鍖朥SART2

    USART_Cmd(USART2, ENABLE);                            //浣胯兘USART2

    USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);        //寮€鍚帴鏀朵腑鏂?
    USART_ITConfig(USART2, USART_IT_IDLE, ENABLE);        

    NVIC_InitStructure.NVIC_IRQChannel = USART2_IRQn;     //USART2涓柇
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 9;//鎶㈠崰浼樺厛绾?
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;     //瀛愪紭鍏堢骇
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;        //浣胯兘涓柇
    NVIC_Init(&NVIC_InitStructure);                        //鍒濆鍖朜VIC

}

//鍙戦€佷竴涓瓧鑺?
void Usart2_SendByte(uint8_t ch)
{
    USART_SendData(USART2, ch);
    while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
}
//鍙戦€佷竴涓瓧绗︿覆
void Usart2_SendString(uint8_t *str)
{
    while(*str != '\0')
    {
        Usart2_SendByte(*str);
        str++;
    }
}

USART2_INFO_T usart2_info;                          //USART2鎺ユ敹鏁版嵁缁撴瀯浣?
volatile uint8_t mqtt_connected = 0;                //MQTT杩炴帴鏍囧織
//鎺ユ敹涓€涓瓧鑺?
uint8_t Usart2_ReceiveByte(void)
{
    if(USART_GetFlagStatus(USART2, USART_FLAG_RXNE) != RESET)
    {
        return (uint8_t)USART_ReceiveData(USART2);
    }

    return 0;
}

//涓柇鏈嶅姟鍑芥暟,鎺ユ敹鏁版嵁
void USART2_IRQHandler(void)
{
    if (USART_GetITStatus(USART2, USART_IT_RXNE) != RESET)
    {
        USART_ClearITPendingBit(USART2, USART_IT_RXNE); //娓呴櫎涓柇鏍囧織浣?
        if(usart2_info.index < USART2_RX_BUF_SIZE-1)
        {
            usart2_info.rx_buf[usart2_info.index++] = USART_ReceiveData(USART2);
              usart2_info.rx_buf[usart2_info.index] = '\0';
        }
        else
        {
            usart2_info.wifi_state = WIFI_RX_BUF_FULL;//鎺ユ敹缂撳啿鍖烘孩鍑?
        }
    }
        if (USART_GetITStatus(USART2, USART_IT_IDLE) != RESET)
        {
        USART2->SR;
        USART2->DR;
        if(strstr((char *)usart2_info.rx_buf, "+MQTTSUBRECV") != NULL)
        {
            usart2_info.wifi_state = WIFI_MQTT_SUB;
    
        }
        else if(strstr((char *)usart2_info.rx_buf, "+MQTTCONNECTED") != NULL)
        {
            /* MQTT 杩炴帴鎴愬姛 */
            mqtt_connected = 1;
            usart2_info.wifi_state = WIFI_MQTT_CONNECTED;
            printf("[MQTT] CONNECTED:%s\r\n", (char*)usart2_info.rx_buf);
        }
        else if(strstr((char *)usart2_info.rx_buf, "+MQTTDISCONNECTED") != NULL)
        {
            /* MQTT 鏂紑杩炴帴 */
            mqtt_connected = 0;
            usart2_info.wifi_state = WIFI_MQTT_DISCONNECTED;
            printf("[MQTT] DISCONNECTED:%s\r\n", (char*)usart2_info.rx_buf);
        }
        else if(strstr((char *)usart2_info.rx_buf, "ERROR") != NULL)
        {
            /* ERROR 浼樺厛浜?OK锛岄伩鍏嶅悓甯ч噷璇垽 */
            usart2_info.wifi_state = WIFI_AT_ERROR;
        }
        else if(strstr((char *)usart2_info.rx_buf, "ready") != NULL)
        {
            usart2_info.wifi_state = WIFI_AT_OK;
        }
        else if(strstr((char *)usart2_info.rx_buf, "OK") != NULL)
        {
            usart2_info.wifi_state = WIFI_AT_OK;
        }
    }
}