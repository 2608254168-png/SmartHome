#ifndef _SPI_H_
#define _SPI_H_

#include "stm32f10x.h"                  // Device header

void SPI2_Init(void);
void SPI2_Transfer(u8 Tbyte);

#endif
