#ifndef _STEP_MOTOR_H_
#define _STEP_MOTOR_H_

#include "stm32f10x.h"
#include "FreeRTOS.h"
#include "task.h"

#define PA4_H    GPIO_SetBits(GPIOA, GPIO_Pin_4)
#define PA4_L    GPIO_ResetBits(GPIOA, GPIO_Pin_4)
#define PA5_H    GPIO_SetBits(GPIOA, GPIO_Pin_5)
#define PA5_L    GPIO_ResetBits(GPIOA, GPIO_Pin_5)
#define PA6_H    GPIO_SetBits(GPIOA, GPIO_Pin_6)
#define PA6_L    GPIO_ResetBits(GPIOA, GPIO_Pin_6)
#define PA7_H    GPIO_SetBits(GPIOA, GPIO_Pin_7)
#define PA7_L    GPIO_ResetBits(GPIOA, GPIO_Pin_7)

void Step_Motor_Init(void);
void Step_Motor_Run(uint8_t dir, uint16_t circle);

#endif
