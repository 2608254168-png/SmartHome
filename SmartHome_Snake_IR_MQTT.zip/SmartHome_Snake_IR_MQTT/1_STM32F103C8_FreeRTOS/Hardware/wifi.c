#include "wifi.h"
#include "menu.h"
#include "rtc.h"

uint8_t WiFi_SNTP_Config(void);
uint8_t WiFi_SNTP_SyncTime(void);
uint8_t WiFi_SNTP_TryResync(void);
/* ================= MQTT/WiFi 连接配置 ================= */
#define WIFI_SSID        "disney phone"
#define WIFI_PWD         "1234qwer"
// #define MQTT_CLIENT      "Dasiy"
#define MQTT_CLIENT      "Dasiy_test123"
#define MQTT_USERNAME    "y8h2hs8n120zglsz"
#define MQTT_PASSWORD    "ikIRyUvKCt"
#define MQTT_HOST        "sh-3-mqtt.iot-api.com"
#define MQTT_PORT        1883
#define MQTT_UPLOAD_TOPIC  "attributes"
#define MQTT_PUSH_TOPIC    "attributes/push"
/* 1=初始化成功后发送hello测试；连不上时会自动跳过 */
#define MQTT_DEBUG_PUBLISH_TEST  1
/* ===================================================== */
uint8_t hex_char2val(char c)
{
    if (c >= '0' && c <= '9') return (uint8_t)(c - '0');
    if (c >= 'a' && c <= 'f') return (uint8_t)(c - 'a' + 10);
    if (c >= 'A' && c <= 'F') return (uint8_t)(c - 'A' + 10);
    return 0;
}

void parse_rgb_hex(char *str, uint8_t *r, uint8_t *g, uint8_t *b)
{
    str++; /* skip '#' */
    *r = (uint8_t)(hex_char2val(str[0]) * 16 + hex_char2val(str[1]));
    *g = (uint8_t)(hex_char2val(str[2]) * 16 + hex_char2val(str[3]));
    *b = (uint8_t)(hex_char2val(str[4]) * 16 + hex_char2val(str[5]));
}

/* 发送AT，支持busy重试；返回0=OK, 1=ERROR, 2=BUF, 3=超时 */
uint8_t WiFi_SendAT(char *cmd, uint32_t timeout)
{
    uint16_t time;
    uint8_t try;
    for (try = 0; try < 3; try++)
    {
        memset(&usart2_info, 0, sizeof(usart2_info));
        Usart2_SendString((uint8_t *)cmd);
        time = 0;
        while (1)
        {
            delay_ms(1);
            time++;
            /* 模块忙：等一会儿再重发本条命令 */
            if (strstr((char *)usart2_info.rx_buf, "busy") != NULL)
            {
                printf("[WiFi] busy, retry cmd\r\n");
                delay_ms(300);
                break; /* 跳出 while，进入下一次 try */
            }
            if (usart2_info.wifi_state == WIFI_AT_OK ||
                usart2_info.wifi_state == WIFI_MQTT_CONNECTED)
            {
                printf("%s", usart2_info.rx_buf);
                return 0;
            }
            if (usart2_info.wifi_state == WIFI_AT_ERROR ||
                usart2_info.wifi_state == WIFI_MQTT_DISCONNECTED)
            {
                printf("%s", usart2_info.rx_buf);
                return 1;
            }
            if (usart2_info.wifi_state == WIFI_RX_BUF_FULL)
                return 2;
            if (time > timeout)
            {
                printf("[WiFi] AT timeout: %s", cmd);
                return 3;
            }
        }
    }
    return 3;
}
uint8_t WiFi_Connect(char *ssid, char *pwd)
{
    char cmd[100];
    sprintf(cmd, "AT+CWJAP=\"%s\",\"%s\"\r\n", ssid, pwd);
    /* 路由器分配IP可能较慢，超时给长一点 */
    return WiFi_SendAT(cmd, 20000);
}
/* 确认拿到IP */
static uint8_t WiFi_WaitGotIP(void)
{
    uint8_t i;
    for (i = 0; i < 10; i++)
    {
        memset(&usart2_info, 0, sizeof(usart2_info));
        Usart2_SendString((uint8_t *)"AT+CIFSR\r\n");
        delay_ms(800);
        /* STAIP 非0.0.0.0即认定拿到地址 */
        if (strstr((char *)usart2_info.rx_buf, "STAIP") != NULL &&
            strstr((char *)usart2_info.rx_buf, "0.0.0.0") == NULL)
        {
            printf("[WiFi] got IP: %s\r\n", (char *)usart2_info.rx_buf);
            return 0;
        }
        delay_ms(500);
    }
    printf("[WiFi] no IP yet\r\n");
    return 1;
}
uint8_t WiFi_SetMQTT(char *client, char *username, char *password)
{
    char cmd[160];
    sprintf(cmd, "AT+MQTTUSERCFG=0,1,\"%s\",\"%s\",\"%s\",0,0,\"\"\r\n",
            client, username, password);
    return WiFi_SendAT(cmd, 3000);
}
uint8_t WiFi_MQTTWaitConnected(uint32_t timeout)
{
    uint32_t time = 0;
    while (time <= timeout)
    {
        delay_ms(1);
        time++;
        if (mqtt_connected)
        {
            printf("[WiFi] MQTT connected\r\n");
            return 0;
        }
        if (usart2_info.wifi_state == WIFI_MQTT_DISCONNECTED)
        {
            printf("[WiFi] MQTT disconnected while waiting\r\n");
            return 1;
        }
    }
    printf("[WiFi] MQTT wait connect timeout\r\n");
    return 2;
}
uint8_t WiFi_MQTTQueryState(void)
{
    uint8_t state = 0xFF;
    char *p;
    uint16_t t;
    memset(&usart2_info, 0, sizeof(usart2_info));
    Usart2_SendString((uint8_t *)"AT+MQTTCONN?\r\n");
    for (t = 0; t < 2000; t++)
    {
        delay_ms(1);
        p = strstr((char *)usart2_info.rx_buf, "+MQTTCONN:0,");
        if (p != NULL)
        {
            state = (uint8_t)(p[12] - '0');
            break;
        }
        if (strstr((char *)usart2_info.rx_buf, "ERROR") != NULL)
            break;
    }
    printf("[WiFi] MQTT query state=%d\r\n", state);
    return state;
}
/* 清理MQTT会话，失败的半连接必须CLEAN后才能重配 */
static uint8_t WiFi_MQTTClean(void)
{
    mqtt_connected = 0;
    return WiFi_SendAT("AT+MQTTCLEAN=0\r\n", 3000);
}
/*
 * 完整MQTT连接流程（每次重连都走一遍）：
 *   CLEAN -> USERCFG -> CONNCFG -> CONN -> 等待+MQTTCONNECTED -> SUB
 */
static uint8_t WiFi_MQTTConnectFull(void)
{
    char cmd[128];
    uint8_t ret;
    WiFi_MQTTClean();
    delay_ms(300);
    if (WiFi_SetMQTT(MQTT_CLIENT, MQTT_USERNAME, MQTT_PASSWORD) != 0)
    {
        printf("[WiFi] MQTTUSERCFG fail\r\n");
        return 1;
    }
    delay_ms(200);
    /* keepalive=60, clean session=0 */
    if (WiFi_SendAT("AT+MQTTCONNCFG=0,60,0,\"\",\"\",0,0\r\n", 3000) != 0)
    {
        printf("[WiFi] MQTTCONNCFG fail\r\n");
        return 2;
    }
    delay_ms(200);
    mqtt_connected = 0;
    memset(&usart2_info, 0, sizeof(usart2_info));
    /* reconnect=0：失败后由我们主动CLEAN重连，避免模块内部乱重试占资源 */
    sprintf(cmd, "AT+MQTTCONN=0,\"%s\",%d,0\r\n", MQTT_HOST, MQTT_PORT);
    ret = WiFi_SendAT(cmd, 15000);
    if (ret != 0)
    {
        printf("[WiFi] MQTTCONN cmd fail ret=%d\r\n", ret);
        return 3;
    }
    if (mqtt_connected == 0)
    {
        if (WiFi_MQTTWaitConnected(15000) != 0)
            return 4;
    }
    if (WiFi_MQTTSubscribe(MQTT_PUSH_TOPIC) != 0)
    {
        printf("[WiFi] MQTTSUB fail\r\n");
        return 5;
    }
    printf("[WiFi] MQTT full connect OK\r\n");
    return 0;
}
uint8_t WiFi_MQTTConnect(char *server)
{
    (void)server;
    return WiFi_MQTTConnectFull();
}
uint8_t WiFi_MQTTSubscribe(char *topic)
{
    char cmd[100];
    sprintf(cmd, "AT+MQTTSUB=0,\"%s\",1\r\n", topic);
    return WiFi_SendAT(cmd, 5000);
}
/**
 * @brief MQTT重连函数
 * 当MQTT连接断开时，尝试重新建立连接
 */
void WiFi_MQTTReconnect(void)
{
    uint8_t i;           // 循环计数器
    uint8_t state;       // MQTT状态变量
    // 如果已经连接，直接返回
    if (mqtt_connected)
        return;
    printf("[WiFi] MQTT reconnecting...\r\n");  // 打印重连开始信息
    // 获取当前MQTT连接状态
    state = WiFi_MQTTQueryState();
    // 检查当前状态是否为已连接状态（4、5、6）
    if (state == 4 || state == 5 || state == 6)
    {
        mqtt_connected = 1;  // 设置连接标志为已连接
        printf("[WiFi] MQTT already connected, state=%d\r\n", state);  // 打印已连接信息
        // 如果状态为4或5，重新订阅主题
        if (state == 4 || state == 5)
            WiFi_MQTTSubscribe(MQTT_PUSH_TOPIC);
        return;
    }
    // 尝试重连，最多尝试3次
    for (i = 0; i < 3; i++)
    {
        // 如果连接成功，返回
        if (WiFi_MQTTConnectFull() == 0)
        {
            printf("[WiFi] MQTT reconnect ok\r\n");  // 打印连接成功信息
            return;
        }
        delay_ms(1500);  // 等待1.5秒后继续下一次尝试
    }
    // 如果3次尝试都失败，打印失败信息
    printf("[WiFi] MQTT reconnect failed\r\n");
}
uint8_t WiFi_MQTTPublish(char *topic, char *data)
{
    uint16_t len, time;
    char cmd[64];
    if (!mqtt_connected)
    {
        printf("[WiFi] publish skip, mqtt not connected\r\n");
        return 1;
    }
    len = (uint16_t)strlen(data);
    sprintf(cmd, "AT+MQTTPUBRAW=0,\"%s\",%d,0,0\r\n", topic, len);
    printf("MQTT CMD:%s\r\n", cmd);
    Usart2_SendString((uint8_t *)cmd);
    memset(&usart2_info, 0, sizeof(usart2_info));
    time = 0;
    while (1)
    {
        delay_ms(1);
        time++;
        if (strchr((char *)usart2_info.rx_buf, '>') != NULL)
            break;
        if (usart2_info.wifi_state == WIFI_AT_ERROR)
            return 1;
        if (strstr((char *)usart2_info.rx_buf, "busy") != NULL)
        {
            delay_ms(200);
            Usart2_SendString((uint8_t *)cmd);
            memset(&usart2_info, 0, sizeof(usart2_info));
            time = 0;
            continue;
        }
        if (time > 3000)
            return 2;
    }
    Usart2_SendString((uint8_t *)data);
    memset(&usart2_info, 0, sizeof(usart2_info));
    time = 0;
    while (1)
    {
        delay_ms(1);
        time++;
        if (strstr((char *)usart2_info.rx_buf, "+MQTTPUB:OK") != NULL)
        {
            printf("[WiFi] MQTTPUB ok\r\n");
            return 0;
        }
        if (strstr((char *)usart2_info.rx_buf, "+MQTTPUB:FAIL") != NULL)
        {
            printf("[WiFi] MQTTPUB FAIL\r\n");
            return 1;
        }
        if (usart2_info.wifi_state == WIFI_AT_ERROR)
            return 1;
        if (time > 5000)
            return 2;
    }
}
/**
 * @brief WiFi模块初始化函数
 * 该函数完成WiFi模块的初始化、连接、时间同步和MQTT连接等操作
 */
void WiFi_Init(void)
{
    uint8_t retry;    // 重试次数计数器     // 函数返回值存储变量
    uint8_t ret;
    // 初始化USART2（串口通信）
    Usart2_Init();
    delay_ms(300);    // 等待模块稳定
    /* 1. AT 握手 */
    for (retry = 0; retry < 8; retry++)
    {
        if (WiFi_SendAT("AT\r\n", 1000) == 0)
            break;
        printf("[WiFi] AT not ready, retry=%d\r\n", retry + 1);
        delay_ms(400);
    }
    /* 2. 复位模块 */
    WiFi_SendAT("AT+RST\r\n", 2000);
    delay_ms(2000);
    /* 等待ready */
    for (retry = 0; retry < 10; retry++)
    {
        if (WiFi_SendAT("AT\r\n", 1000) == 0)
            break;
        delay_ms(300);
    }
    /* 3. Station模式（不要用CWMODE=1,0，部分固件不支持第二个参数会ERROR） */
    for (retry = 0; retry < 3; retry++)
    {
        if (WiFi_SendAT("AT+CWMODE=1\r\n", 2000) == 0)
            break;
        delay_ms(300);
    }
    /* 关闭多连接，避免干扰 */
    WiFi_SendAT("AT+CIPMUX=0\r\n", 1000);
    /* 4. 连接WiFi */
    ret = 1;
    for (retry = 0; retry < 5; retry++)
    {
        ret = WiFi_Connect(WIFI_SSID, WIFI_PWD);
        if (ret == 0)
            break;
        printf("[WiFi] CWJAP failed ret=%d, retry=%d\r\n", ret, retry + 1);
        delay_ms(2000);
    }
    if (ret != 0)
    {
        printf("[WiFi] WiFi connect FAILED, skip MQTT/SNTP\r\n");
        return;
    }
    /* 确认拿到IP，否则后面MQTT/DNS必定失败 */
    if (WiFi_WaitGotIP() != 0)
    {
        printf("[WiFi] no IP, skip MQTT/SNTP\r\n");
        return;
    }
    /* 4.1 SNTP对时（软件时钟基准） */
    printf("[WiFi] start SNTP time sync...\r\n");
    if (WiFi_SNTP_Config() == 0)
    {
        delay_ms(2500);
        if (WiFi_SNTP_SyncTime() == 0)
            printf("[WiFi] SNTP sync OK\r\n");
        else
            printf("[WiFi] SNTP sync FAILED (soft clock keeps default)\r\n");
    }
    else
    {
        printf("[WiFi] SNTP config FAILED\r\n");
    }
    /* 5. MQTT完整连接 */
    for (retry = 0; retry < 3; retry++)
    {
        if (WiFi_MQTTConnectFull() == 0)
            break;
        printf("[WiFi] MQTT connect failed, retry=%d\r\n", retry + 1);
        delay_ms(1500);
    }
#if MQTT_DEBUG_PUBLISH_TEST
    if (mqtt_connected)
    {
        printf("[WiFi] TEST publish 'hello' to %s ...\r\n", MQTT_UPLOAD_TOPIC);
        if (WiFi_MQTTPublish(MQTT_UPLOAD_TOPIC, "hello") == 0)
            printf("[WiFi] TEST publish hello OK\r\n");
        else
            printf("[WiFi] TEST publish hello FAILED\r\n");
    }
    else
    {
        printf("[WiFi] skip TEST publish (mqtt not connected)\r\n");
    }
#endif
    printf("[WiFi] Init done, mqtt_connected=%d\r\n", mqtt_connected);
}
/* -------------------- 下发解析 / 上报 -------------------- */
/**
 * @brief 解析WiFi接收到的数据，并根据内容更新设备状态
 * @note 该函数会检查WiFi模块的状态，只有在MQTT订阅状态下才会处理数据
 */
void WiFi_ParseData(void)
{
    // 检查WiFi状态是否为MQTT订阅模式，如果不是则直接返回
    if (usart2_info.wifi_state != WIFI_MQTT_SUB)
        return;
    // 打印接收到的原始数据
    printf("%s\r\n", usart2_info.rx_buf);
    if (strstr((char *)usart2_info.rx_buf, "\"led1\":1") != NULL) g_dev.led1 = 1;
    else if (strstr((char *)usart2_info.rx_buf, "\"led1\":0") != NULL) g_dev.led1 = 0;
    if (strstr((char *)usart2_info.rx_buf, "\"led2\":1") != NULL) g_dev.led2 = 1;
    else if (strstr((char *)usart2_info.rx_buf, "\"led2\":0") != NULL) g_dev.led2 = 0;
    if (strstr((char *)usart2_info.rx_buf, "\"led3\":1") != NULL) g_dev.led3 = 1;
    else if (strstr((char *)usart2_info.rx_buf, "\"led3\":0") != NULL) g_dev.led3 = 0;
    if (strstr((char *)usart2_info.rx_buf, "\"relay\":1") != NULL) g_dev.relay = 1;
    else if (strstr((char *)usart2_info.rx_buf, "\"relay\":0") != NULL) g_dev.relay = 0;
    if (strstr((char *)usart2_info.rx_buf, "\"curtain\":1") != NULL) g_dev.curtain = 1;
    else if (strstr((char *)usart2_info.rx_buf, "\"curtain\":0") != NULL) g_dev.curtain = 0;
    {
        char *fan_ptr = strstr((char *)usart2_info.rx_buf, "\"fan\":");
        int fan_value;
        if (fan_ptr != NULL && sscanf(fan_ptr, "\"fan\":%d", &fan_value) == 1)
        {
            if (fan_value > 100) fan_value = 100;
            if (fan_value < -100) fan_value = -100;
            g_dev.fan = (int16_t)fan_value;
        }
    }
    {
        char *rgb_ptr = strstr((char *)usart2_info.rx_buf, "#");
        uint8_t r, g, b;
        if (rgb_ptr != NULL)
        {
            parse_rgb_hex(rgb_ptr, &r, &g, &b);
            g_dev.rgb_r = r;
            g_dev.rgb_g = g;
            g_dev.rgb_b = b;
        }
    }
    Dev_Apply();
    memset(usart2_info.rx_buf, 0, USART2_RX_BUF_SIZE);
    usart2_info.index = 0;
    usart2_info.wifi_state = WIFI_STATE_IDLE;
}
void WiFi_DeviceStateUpload(void)
{
    char json[180];
    if (!mqtt_connected)
    {
        WiFi_MQTTReconnect();
        if (!mqtt_connected)
            return;
    }
    sprintf(json,
            "{\"led1\":%d,\"led2\":%d,\"led3\":%d,"
            "\"relay\":%d,\"curtain\":%d,\"fan\":%d,"
            "\"rgb\":\"#%02X%02X%02X\"}",
            g_dev.led1, g_dev.led2, g_dev.led3,
            g_dev.relay, g_dev.curtain, g_dev.fan,
            g_dev.rgb_r, g_dev.rgb_g, g_dev.rgb_b);
    if (WiFi_MQTTPublish(MQTT_UPLOAD_TOPIC, json) == 0)
        g_dev_report_pending = 0;
    else if (WiFi_MQTTQueryState() < 4)
        mqtt_connected = 0;
}
void WiFi_DHT11_Upload(void)
{
    float temperature;
    uint8_t humidity;
    char json[64];
    if (!mqtt_connected)
    {
        WiFi_MQTTReconnect();
        if (!mqtt_connected)
        {
            printf("upload skip, mqtt not connected\r\n");
            return;
        }
    }
    if (DHT11_GetData(&temperature, &humidity) == 0)
    {
        sprintf(json, "{\"temperature\":%.1f,\"humidity\":%d}", temperature, humidity);
        printf("upload:%s\r\n", json);
        if (WiFi_MQTTPublish(MQTT_UPLOAD_TOPIC, json) != 0)
        {
            printf("[WiFi] publish FAILED\r\n");
            if (WiFi_MQTTQueryState() < 4)
                mqtt_connected = 0;
        }
    }
}
//安全上传
/**
 * @brief 安全数据上传函数
 * 通过MQTT协议将安全相关的传感器数据上传到服务器
 * 包括入侵警报、火灾状态、低温警报、温度和湿度信息
 */
void WiFi_Safety_Upload(void)
{
    char payload[160];  // 用于存储JSON格式数据的缓冲区
    // 检查MQTT连接状态，如果未连接则尝试重新连接
    if (!mqtt_connected)
    {
        WiFi_MQTTReconnect();  // 尝试重新连接MQTT服务器
        if (!mqtt_connected)   // 如果重连失败则直接返回
            return;
    }
    // 将安全数据格式化为JSON字符串
    sprintf(payload,
            "{\"distance_alert\":%d,\"fire_status\":%d,\"temp_low\":%d,"
            "\"temperature\":%.1f,\"humidity\":%d}",
            (g_safety.alert_latched & ALERT_INTRUSION) ? 1 : 0,    // 入侵警报状态
            (g_safety.alert_latched & ALERT_FIRE) ? 1 : 0,         // 火灾警报状态
            (g_safety.alert_latched & ALERT_TEMP_LOW) ? 1 : 0,      // 低温警报状态
            g_safety.temperature,                                   // 温度值
            g_safety.humidity);                                    // 湿度值
    printf("safety upload:%s\r\n", payload);  // 打印上传的数据内容
    // 发布数据到MQTT主题
    if (WiFi_MQTTPublish(MQTT_UPLOAD_TOPIC, payload) != 0)
    {
        // 如果发布失败且连接状态异常，则断开MQTT连接
        if (WiFi_MQTTQueryState() < 4)
            mqtt_connected = 0;
    }
}
/* ======================== SNTP ======================== */
static const char *const s_month_name[12] = {
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
static int month_str2num(const char *m)
{
    int i;
    for (i = 0; i < 12; i++)
    {
        if (m[0] == s_month_name[i][0] &&
            m[1] == s_month_name[i][1] &&
            m[2] == s_month_name[i][2])
            return i + 1;
    }
    return 0;
}
/**
 * @brief 配置WiFi模块的SNTP时间同步功能
 * 
 * @return uint8_t 返回值：0表示配置成功，1表示配置失败
 */
uint8_t WiFi_SNTP_Config(void)
{
    uint8_t retry;  // 用于重试计数的变量
    // 定义SNTP配置命令，设置时区为8，并配置阿里云的NTP服务器
    const char *cmd =
        "AT+CIPSNTPCFG=1,8,\"ntp.aliyun.com\",\"ntp1.aliyun.com\",\"ntp2.aliyun.com\"\r\n";
    // 最多重试3次配置
    for (retry = 0; retry < 3; retry++)
    {
        // 发送AT命令，如果成功则返回0
        if (WiFi_SendAT((char *)cmd, 3000) == 0)
        {
            printf("[WiFi] SNTP config OK\r\n");  // 打印配置成功信息
            return 0;  // 配置成功，返回0
        }
        delay_ms(500);  // 如果发送失败，等待500ms后重试
    }
    // 如果3次重试都失败，返回1表示配置失败
    return 1;
}
uint8_t WiFi_SNTP_SyncTime(void)
{
    char *p;
    char mon[4] = {0};
    int year = 0, month = 0, day = 0;
    int hour = 0, min = 0, sec = 0;
    int n;
    uint16_t t;
    uint8_t retry;
    for (retry = 0; retry < 5; retry++)
    {
        memset(&usart2_info, 0, sizeof(usart2_info));
        Usart2_SendString((uint8_t *)"AT+CIPSNTPTIME?\r\n");
        for (t = 0; t < 3000; t++)
        {
            delay_ms(1);
            if (usart2_info.wifi_state == WIFI_AT_OK ||
                usart2_info.wifi_state == WIFI_AT_ERROR ||
                usart2_info.wifi_state == WIFI_RX_BUF_FULL)
                break;
        }
        printf("[SNTP] resp: %s\r\n", (char *)usart2_info.rx_buf);
        p = strstr((char *)usart2_info.rx_buf, "+CIPSNTPTIME:");
        if (p == NULL)
        {
            delay_ms(500);
            continue;
        }
        p += 13;
        n = sscanf(p, "%*s %3s %d %d:%d:%d %d",
                   mon, &day, &hour, &min, &sec, &year);
        if (n != 6)
        {
            n = sscanf(p, "%*3s %3s %d %d:%d:%d %d",
                       mon, &day, &hour, &min, &sec, &year);
        }
        if (n != 6)
        {
            printf("[SNTP] parse fail n=%d\r\n", n);
            delay_ms(500);
            continue;
        }
        month = month_str2num(mon);
        if (month == 0 || year < 2020 || year > 2099 ||
            day < 1 || day > 31 || hour > 23 || min > 59 || sec > 59)
        {
            printf("[SNTP] invalid %04d-%02d-%02d %02d:%02d:%02d\r\n",
                   year, month, day, hour, min, sec);
            delay_ms(1000);
            continue;
        }
        My_Time[0] = (uint16_t)year;
        My_Time[1] = (uint16_t)month;
        My_Time[2] = (uint16_t)day;
        My_Time[3] = (uint16_t)hour;
        My_Time[4] = (uint16_t)min;
        My_Time[5] = (uint16_t)sec;
        My_RTC_SetTime();
        printf("[SNTP] set %04d-%02d-%02d %02d:%02d:%02d\r\n",
               year, month, day, hour, min, sec);
        return 0;
    }
    return 1;
}
/**
 * @brief 尝试重新同步SNTP时间
 * @return uint8_t 返回值：0表示成功，非0表示失败
 */
uint8_t WiFi_SNTP_TryResync(void)
{
    // 首先尝试配置SNTP
    if (WiFi_SNTP_Config() != 0)
        return 1;  // 如果配置失败，直接返回1表示失败
    delay_ms(500);  // 等待500毫秒，让配置生效
    // 同步时间并返回结果
    return WiFi_SNTP_SyncTime();
}
